"""
Persona assignment module for SpendSenseAI.

This module assigns users to financial personas based on detected behaviors.
"""

__version__ = "0.1.0"

