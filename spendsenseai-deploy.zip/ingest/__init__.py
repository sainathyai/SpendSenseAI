"""
Data ingestion module for SpendSenseAI.

This module handles loading and validating Plaid-style transaction data.
"""

__version__ = "0.1.0"

